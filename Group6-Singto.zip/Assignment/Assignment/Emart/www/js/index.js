const products = [
    { name: "Asus Gaming Laptop", onSale: false, image: "laptop.jpg" },
    { name: "Gamers Headphones", onSale: true, image: "headphones.jpg" },
    { name: "Cetaphil", onSale: false, image: "cetaphil.jpg" },
    { name: "Women Blouse", onSale: true, image: "blouse.jpg" },
    { name: "Digital Airfryer", onSale: false, image: "airfryer.jpg" },
    { name: "Maybelline Lipstick", onSale: true, image: "lipstick.jpg" }
  ];
  
  const productList = document.getElementById("productList");
  
  const productSection = document.createElement("section");
  productSection.classList.add("product-section");
  
  const onSaleSection = document.createElement("section");
  onSaleSection.classList.add("product-section");
  
  const productDivs = [];
  const onSaleDivs = [];
  
  products.forEach((product, index) => {
    const productDiv = document.createElement("div");
    productDiv.classList.add("product");
  
    const image = document.createElement("img");
    image.src = product.image;
    productDiv.appendChild(image);
  
    const nameSpan = document.createElement("span");
    nameSpan.classList.add("name");
    nameSpan.textContent = product.name;
    productDiv.appendChild(nameSpan);
  
    if (product.onSale) {
      const onSaleSpan = document.createElement("span");
      onSaleSpan.classList.add("on-sale");
      onSaleSpan.textContent = " (On Sale)";
      productDiv.appendChild(onSaleSpan);
    }
  
    if (index < 3) {
      productDivs.push(productDiv);
    } else {
      onSaleDivs.push(productDiv);
    }
  });
  
  productDivs.forEach(productDiv => {
    productSection.appendChild(productDiv);
  });
  
  onSaleDivs.forEach(productDiv => {
    onSaleSection.appendChild(productDiv);
  });
  
  productList.appendChild(productSection);
  productList.appendChild(onSaleSection);
  
  var images = [
    'emart.jpg'
  ];
  
  var slideshow = document.getElementById('slideshow');
  var imageIndex = 0;
  
  function changeSlide() {
    slideshow.src = images[imageIndex];
    imageIndex = (imageIndex + 1) % images.length;
  }
  
  setInterval(changeSlide, 5000);